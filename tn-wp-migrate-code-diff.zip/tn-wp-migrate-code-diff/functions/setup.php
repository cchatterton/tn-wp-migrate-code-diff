<?php

if (!defined('ABSPATH')) {
    exit;
}

function twmcd_register_hooks()
{
    add_action(is_multisite() ? 'network_admin_menu' : 'admin_menu', 'twmcd_register_admin_page');
    add_action('admin_enqueue_scripts', 'twmcd_enqueue_admin_assets');
    add_action('wp_ajax_twmcd_compare_code', 'twmcd_ajax_compare_code');
    add_action('wp_ajax_twmcd_compare_database', 'twmcd_ajax_compare_database');
    add_action('wp_ajax_twmcd_compare_options', 'twmcd_ajax_compare_options');
    add_action('wp_ajax_twmcd_compare_posts', 'twmcd_ajax_compare_posts');
    add_action('wp_ajax_twmcd_prepare_comparison', 'twmcd_ajax_prepare_comparison');
    add_action('wp_ajax_twmcd_save_profile', 'twmcd_ajax_save_profile');
    add_action('wp_ajax_twmcd_prepare_release_package', 'twmcd_ajax_prepare_release_package');
    add_action('wp_ajax_twmcd_prepare_post_release_package', 'twmcd_ajax_prepare_post_release_package');
    add_action('wp_ajax_twmcd_prepare_rollback_package', 'twmcd_ajax_prepare_rollback_package');
    add_action('wp_ajax_twmcd_get_release_history_month', 'twmcd_ajax_get_release_history_month');
    add_action('wp_ajax_twmcd_search_release_history', 'twmcd_ajax_search_release_history');
    add_action('admin_post_twmcd_create_release_package', 'twmcd_handle_create_release_package');
    add_action('admin_post_twmcd_download_release_package', 'twmcd_handle_download_release_package');
    add_action('admin_post_twmcd_upload_release', 'twmcd_handle_release_upload');
    add_filter('plugin_action_links_' . plugin_basename(TWMCD_PLUGIN_FILE), 'twmcd_add_plugin_action_link');
    add_filter('pre_set_site_transient_update_plugins', 'twmcd_add_github_update_data');
    add_filter('site_transient_update_plugins', 'twmcd_add_github_update_data');
    add_filter('plugins_api', 'twmcd_github_plugin_information', 20, 3);
    add_filter('plugin_row_meta', 'twmcd_add_github_plugin_row_meta', 10, 2);
    add_action('admin_init', 'twmcd_handle_manual_update_check');
    add_action('admin_init', 'twmcd_repair_legacy_release_profiles');
    add_action('upgrader_process_complete', 'twmcd_clear_github_cache_after_upgrade', 10, 2);
    add_action('wpmdb_notices', 'twmcd_render_integration_notice_mount');
    add_filter('wpmdb_respond_to_verify_connection_key_rules', 'twmcd_add_remote_comparison_key_rules');
    add_filter('wpmdb_establish_remote_connection_data', 'twmcd_extend_remote_connection_data', 30);
}

twmcd_register_hooks();
register_activation_hook(TWMCD_PLUGIN_FILE, 'twmcd_install_release_history_table');
