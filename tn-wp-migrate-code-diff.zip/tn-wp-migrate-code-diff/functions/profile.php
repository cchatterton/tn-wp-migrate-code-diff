<?php

if (!defined('ABSPATH')) {
    exit;
}

function twmcd_create_code_only_profile($profile_name, $context, $selection)
{
    $intent = $context['intent'];
    $connection_info = $context['connection_info'];
    $connection = $context['connection'];
    $multisite_tools = isset($context['multisite_tools']) && is_array($context['multisite_tools'])
        ? $context['multisite_tools']
        : array('enabled' => false);
    $migration_context = isset($context['migration']) && is_array($context['migration'])
        ? $context['migration']
        : array();
    $plugins = twmcd_sanitize_profile_paths(isset($selection['plugins']) ? $selection['plugins'] : array());
    $themes = twmcd_sanitize_profile_paths(isset($selection['themes']) ? $selection['themes'] : array());
    $mu_plugins = twmcd_sanitize_profile_paths(isset($selection['muplugins']) ? $selection['muplugins'] : array());
    $default_exclusions = ".DS_Store\n.git\nnode_modules";

    return array(
        '_twmcd' => array(
            'profile_schema' => 2,
        ),
        'current_migration' => array(
            'connected'                 => true,
            'intent'                    => $intent,
            'tables_option'             => 'all',
            'tables_selected'           => array(),
            'backup_option'             => 'none',
            'backup_tables_selected'    => array(),
            'post_types_option'         => 'all',
            'post_types_selected'       => array(),
            'advanced_options_selected' => array(),
            'profile_name'              => $profile_name,
            'selected_existing_profile' => null,
            'profile_type'              => null,
            'status'                    => array('disabled' => false),
            'stages'                    => array(),
            'current_stage'             => '',
            'stages_complete'            => array(),
            'running'                   => false,
            'migration_enabled'         => false,
            'migration_id'              => wp_generate_uuid4(),
            'source_prefix'             => '',
            'destination_prefix'        => '',
            'preview'                   => false,
            'selectedComboOption'       => 'preview',
            'databaseEnabled'           => false,
            'localSource'               => !empty($migration_context['local_source']),
            'twoMultisites'             => !empty($migration_context['two_multisites']),
            'currentPayloadSize'        => 0,
            'currentMaxPayloadSize'     => null,
            'fileTransferRequests'      => 0,
            'payloadSizeHistory'        => array(),
            'fileTransferStats'          => array(),
            'forceHighPerformanceTransfers' => true,
            'highPerformanceTransfersStatus' => false,
            'fseDumpFilename'           => null,
        ),
        'connection_info' => array(
            'connection_state' => array(
                'value' => $connection_info,
                'url'   => $connection['url'],
                'key'   => $connection['key'],
            ),
            'status' => array(
                'auth_form'                    => array('username' => '', 'password' => ''),
                'show_auth_form'               => false,
                'connecting'                   => false,
                'error'                        => false,
                'error_msg'                    => '',
                'button_status'                => 'disabled',
                'ssl_notice'                   => false,
                'pasted'                       => false,
                'copy_to_remote'               => false,
                'prefix_mismatch'              => false,
                'mixed_case_table_name_warning' => false,
                'show_mst_warning'             => false,
                'update_plugin_on_remote'      => false,
                'retry_over_http'              => false,
            ),
        ),
        'search_replace' => twmcd_complete_search_replace_profile_state(array()),
        'media_files' => twmcd_complete_media_profile_state(array('enabled' => false)),
        'theme_plugin_files' => array(
            'available'          => true,
            'is_licensed'        => true,
            'message'            => '',
            'theme_files'        => array('enabled' => !empty($themes)),
            'themes_option'      => 'selected',
            'themes_selected'    => $themes,
            'themes_excluded'    => array(),
            'themes_excludes'    => $default_exclusions,
            'plugin_files'       => array('enabled' => !empty($plugins)),
            'plugins_option'     => 'selected',
            'plugins_selected'   => $plugins,
            'plugins_excluded'   => array(),
            'plugins_excludes'   => $default_exclusions,
            'muplugin_files'     => array('enabled' => !empty($mu_plugins)),
            'muplugins_option'   => 'selected',
            'muplugins_selected' => $mu_plugins,
            'muplugins_excludes' => $default_exclusions,
            'other_files'        => array('enabled' => false),
            'others_option'      => 'selected',
            'others_selected'    => array(),
            'others_excludes'    => $default_exclusions,
            'core_files'         => array('enabled' => false),
            'core_option'        => 'all',
            'core_selected'      => array(),
            'core_excludes'      => $default_exclusions,
            'state'              => array('status' => ''),
        ),
        'multisite_tools' => twmcd_complete_multisite_profile_state($multisite_tools),
    );
}

function twmcd_complete_multisite_profile_state($multisite_tools)
{
    return array_merge(
        array(
            'enabled'             => false,
            'available'           => true,
            'is_licensed'         => true,
            'selected_subsite'    => 0,
            'destination_subsite' => 0,
            'new_prefix'          => '',
            'message'             => '',
        ),
        is_array($multisite_tools) ? $multisite_tools : array()
    );
}

function twmcd_complete_media_profile_state($media_files)
{
    return array_merge(
        array(
            'enabled'        => false,
            'option'         => 'all',
            'available'      => true,
            'is_licensed'    => true,
            'message'        => '',
            'excludes'       => ".DS_Store\n*.log\n*backup*/\n*cache*/",
            'last_migration' => '',
            'date'           => gmdate('Y-m-d\TH:i:s.000\Z'),
        ),
        is_array($media_files) ? $media_files : array()
    );
}

function twmcd_complete_search_replace_profile_state($search_replace)
{
    $search_replace = is_array($search_replace) ? $search_replace : array();
    $standard_search_replace = isset($search_replace['standard_search_replace'])
        && is_array($search_replace['standard_search_replace'])
        ? $search_replace['standard_search_replace']
        : array();
    $domain = isset($standard_search_replace['domain']) && is_array($standard_search_replace['domain'])
        ? $standard_search_replace['domain']
        : array();
    $path = isset($standard_search_replace['path']) && is_array($standard_search_replace['path'])
        ? $standard_search_replace['path']
        : array();
    $custom_search_replace = !empty($search_replace['custom_search_replace'])
        && is_array($search_replace['custom_search_replace'])
        ? $search_replace['custom_search_replace']
        : array(
            array(
                'replace_old'             => '',
                'replace_new'             => '',
                'focus'                   => false,
                'regex'                   => false,
                'isValidRegex'            => null,
                'replace_old_placeholder' => null,
                'replace_new_placeholder' => null,
                'id'                      => wp_generate_uuid4(),
            ),
        );

    return array(
        'standard_search_replace' => array(
            'domain' => array_merge(array('search' => '', 'replace' => '', 'enabled' => true), $domain),
            'path'   => array_merge(array('search' => '', 'replace' => '', 'enabled' => true), $path),
        ),
        'standard_options_enabled'  => isset($search_replace['standard_options_enabled'])
            ? array_values((array) $search_replace['standard_options_enabled'])
            : array('domain', 'path'),
        'standard_search_visible'   => isset($search_replace['standard_search_visible'])
            ? (bool) $search_replace['standard_search_visible']
            : true,
        'custom_search_replace'     => $custom_search_replace,
        'custom_search_domain_locked' => !empty($search_replace['custom_search_domain_locked']),
    );
}

function twmcd_is_legacy_release_profile($name, $profile)
{
    if (!is_array($profile)
        || !preg_match('/^Release-\d{8}-\d{2}:?\d{2}$/', (string) $name)
        || empty($profile['current_migration'])
        || empty($profile['connection_info']['connection_state'])
        || empty($profile['theme_plugin_files'])) {
        return false;
    }

    $migration = $profile['current_migration'];
    $media_files = isset($profile['media_files']) && is_array($profile['media_files'])
        ? $profile['media_files']
        : array();

    return isset($migration['databaseEnabled'])
        && false === $migration['databaseEnabled']
        && isset($media_files['enabled'])
        && false === $media_files['enabled']
        && isset($profile['theme_plugin_files']['plugins_option'])
        && 'selected' === $profile['theme_plugin_files']['plugins_option'];
}

function twmcd_repair_legacy_release_profiles()
{
    if (2 <= (int) get_site_option('twmcd_profile_schema_version', 0)) {
        return;
    }

    $profiles = get_site_option('wpmdb_saved_profiles');
    $profiles = is_array($profiles) ? $profiles : array();
    $changed = false;

    foreach ($profiles as $profile_id => $stored_profile) {
        $profile = isset($stored_profile['value'])
            ? json_decode($stored_profile['value'], true)
            : null;
        $name = isset($stored_profile['name']) ? $stored_profile['name'] : '';

        if (!twmcd_is_legacy_release_profile($name, $profile)) {
            continue;
        }

        $profile['_twmcd'] = array('profile_schema' => 2);
        $profile['current_migration']['connected'] = true;
        $profile['current_migration']['highPerformanceTransfersStatus'] = false;
        $profile['media_files'] = twmcd_complete_media_profile_state(
            isset($profile['media_files']) ? $profile['media_files'] : array()
        );
        $profile['search_replace'] = twmcd_complete_search_replace_profile_state(
            isset($profile['search_replace']) ? $profile['search_replace'] : array()
        );
        $profile['multisite_tools'] = twmcd_complete_multisite_profile_state(
            isset($profile['multisite_tools']) ? $profile['multisite_tools'] : array()
        );
        $profiles[$profile_id]['value'] = wp_json_encode($profile);
        $changed = true;
    }

    if ($changed) {
        update_site_option('wpmdb_saved_profiles', $profiles);
    }

    update_site_option('twmcd_profile_schema_version', 2);
}

function twmcd_sanitize_profile_paths($paths)
{
    if (!is_array($paths)) {
        return array();
    }

    return array_values(
        array_filter(
            array_map('sanitize_text_field', $paths),
            function ($path) {
                return '' !== $path && 0 !== strpos($path, 'twmcd-remove:');
            }
        )
    );
}

function twmcd_create_comparison_token($context, $comparison_groups)
{
    $token = wp_generate_password(20, false, false);
    $allowed_paths = array(
        'plugins'   => array(),
        'themes'    => array(),
        'muplugins' => array(),
    );

    foreach ($allowed_paths as $group_key => $unused) {
        $group_rows = isset($comparison_groups[$group_key]) && is_array($comparison_groups[$group_key])
            ? $comparison_groups[$group_key]
            : array();

        foreach ($group_rows as $row) {
            if (!empty($row['selection'])) {
                $allowed_paths[$group_key][] = (string) $row['selection'];
            }
        }
    }

    set_site_transient(
        twmcd_comparison_transient_key($token),
        array(
            'context'       => $context,
            'allowed_paths' => $allowed_paths,
            'packages'      => $comparison_groups,
        ),
        15 * MINUTE_IN_SECONDS
    );

    return $token;
}

function twmcd_comparison_transient_key($token)
{
    return 'twmcd_cmp_' . get_current_user_id() . '_' . sanitize_key($token);
}

function twmcd_validate_profile_selection($token, $selection)
{
    $comparison_state = get_site_transient(twmcd_comparison_transient_key($token));

    if (!is_array($comparison_state) || empty($comparison_state['context'])) {
        return new WP_Error(
            'twmcd_expired_comparison',
            __('The comparison has expired. Run the code comparison again before saving.', 'tn-wp-migrate-code-diff')
        );
    }

    $validated_selection = array();
    foreach (array('plugins', 'themes', 'muplugins') as $group_key) {
        $submitted_paths = isset($selection[$group_key]) && is_array($selection[$group_key])
            ? array_map('strval', $selection[$group_key])
            : array();
        $allowed_paths = isset($comparison_state['allowed_paths'][$group_key])
            ? $comparison_state['allowed_paths'][$group_key]
            : array();

        $validated_selection[$group_key] = array_values(array_intersect($submitted_paths, $allowed_paths));

        if (count($validated_selection[$group_key]) !== count($submitted_paths)) {
            return new WP_Error(
                'twmcd_invalid_selection',
                __('The selected packages did not match the latest comparison. Run the comparison again.', 'tn-wp-migrate-code-diff')
            );
        }
    }

    return $validated_selection;
}

function twmcd_get_comparison_state($token)
{
    $comparison_state = get_site_transient(twmcd_comparison_transient_key($token));

    return is_array($comparison_state) ? $comparison_state : false;
}

function twmcd_store_migration_profile($profile_name, $profile)
{
    $profiles = get_site_option('wpmdb_saved_profiles');
    $profiles = is_array($profiles) ? $profiles : array();
    $stored_profile = array(
        'name'  => $profile_name,
        'value' => wp_json_encode($profile),
        'guid'  => wp_generate_uuid4(),
        'date'  => current_time('timestamp'),
    );

    foreach ($profiles as $profile_id => $existing_profile) {
        if (isset($existing_profile['name']) && (string) $existing_profile['name'] === (string) $profile_name) {
            $stored_profile['guid'] = !empty($existing_profile['guid'])
                ? $existing_profile['guid']
                : $stored_profile['guid'];
            $profiles[$profile_id] = $stored_profile;
            update_site_option('wpmdb_saved_profiles', $profiles);

            return $profile_id;
        }
    }

    $profiles[] = $stored_profile;

    update_site_option('wpmdb_saved_profiles', $profiles);

    return max(array_keys($profiles));
}

function twmcd_existing_migration_profile($profile_name)
{
    $profiles = get_site_option('wpmdb_saved_profiles');
    foreach ((array) $profiles as $profile_id => $stored_profile) {
        if (!isset($stored_profile['name']) || (string) $stored_profile['name'] !== (string) $profile_name) {
            continue;
        }
        $profile = !empty($stored_profile['value']) ? json_decode($stored_profile['value'], true) : null;
        return is_array($profile) ? array('id' => $profile_id, 'profile' => $profile) : false;
    }

    return false;
}

function twmcd_store_automatic_comparison_profile($context, $mode)
{
    $destination_url = !empty($context['intent']) && 'push' === $context['intent']
        ? $context['connection']['url']
        : home_url();
    $profile_name = twmcd_default_profile_name($destination_url);
    $profile = twmcd_create_code_only_profile(
        $profile_name,
        $context,
        array('plugins' => array(), 'themes' => array(), 'muplugins' => array())
    );
    $existing = twmcd_existing_migration_profile($profile_name);
    if ($existing && !empty($existing['profile']['theme_plugin_files'])) {
        $profile['theme_plugin_files'] = $existing['profile']['theme_plugin_files'];
    }
    $profile['_twmcd']['last_comparison_mode'] = sanitize_key($mode);

    return twmcd_store_migration_profile($profile_name, $profile);
}
